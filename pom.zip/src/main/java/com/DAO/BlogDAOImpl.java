/**
 * 
 */
package com.DAO;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.Model.BlogModel;
import com.Model.CustModel;

/**
 * @author user
 *
 */
@Repository
public class BlogDAOImpl implements BlogDAO {
	
	@Autowired
	SessionFactory sf;
	Session s;
	Transaction t;

	@Override
	@Transactional
	public void addBlog(BlogModel b) {
		s=sf.openSession();
		t=s.beginTransaction();
		s.saveOrUpdate(b);
		t.commit();
		
		
	}

	@Override
	@Transactional
	public List<BlogModel> viewBlog() {
		List<BlogModel> l;
		Session s=sf.openSession();
		Transaction t=s.beginTransaction();
		l = (List<BlogModel>)s.createCriteria(BlogModel.class).list();
		return l;
	}

}
