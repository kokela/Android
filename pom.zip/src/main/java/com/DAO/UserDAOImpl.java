/**
 * 
 */
package com.DAO;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.Model.CustModel;

@Repository
public class UserDAOImpl implements UserDAO {
	
	@Autowired
	SessionFactory sf;

	@Override
	@Transactional
	public void addCust(CustModel c) {
		Session s= sf.openSession();
		Transaction t= s.beginTransaction();
		c.setEnabled(true);
		s.saveOrUpdate(c);
		t.commit();
	}

	@Override
	@Transactional
	public List<CustModel> viewCust() {
		List<CustModel> l;
		Session s=sf.openSession();
		Transaction t=s.beginTransaction();
		l = (List<CustModel>)s.createCriteria(CustModel.class).list();
		return l;
	}
}
