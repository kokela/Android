package com.Controller;

import java.io.File;
import java.nio.file.Path;
import java.nio.file.Paths;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.DAO.BlogDAO;
import com.DAO.UserDAO;
import com.Model.BlogModel;
import com.Model.CustModel;



@Controller
public class BaseController {
	
	@Autowired
	UserDAO ud;
	@Autowired
	BlogDAO bd;
	
	/*profile
	========================================================================================================*/
	@ModelAttribute("obj")
	public CustModel getOb(){
		return new CustModel();
	}
	@RequestMapping("/save")
	public ModelAndView goInd4(@ModelAttribute("obj")CustModel x,HttpServletRequest req){
		ModelAndView m = new ModelAndView("Index");
		ud.addCust(x);
	
	if (!x.getFile().isEmpty()) {
       		String a=req.getSession().getServletContext().getRealPath("/");
		File f=new File(a+"/resources/assets/upimages/");
		if(!f.exists())
			  f.mkdirs();
		Path path=Paths.get(a+"/resources/assets/upimages/"+ x.getName()+".jpg");
		try{
		x.getFile().transferTo(new File(path.toString()));
		 System.out.println("uploaded sucessfully");
		} 
		catch(Exception e) {
			System.out.println("e");
		}
		}
		else {
			m.setViewName("Login");
         System.out.println("You failed to upload " + x.getName() + " because the file was empty.");
		}
	return m;
		  
     }

	@RequestMapping("/view")
	public ModelAndView goInd2(){
		ModelAndView m = new ModelAndView("profile");
		m.addObject("data",ud.viewCust());
	return m;
	}
	
	
	/*blog
	 ==============================================================================*/
	
	@RequestMapping("/blogging")
	public String goblogging(){
		System.out.println("In blogging");
		return "blogging";
		} 
	
	@RequestMapping("/blog")
	public String goblog(){
		System.out.println("In blog");
		return "blog";
		}
	@ModelAttribute("blo")
	public BlogModel getblo(){
		return new BlogModel();
	}  
	@RequestMapping("/createblog")
	public String gocreateblog(){
		System.out.println("In createblog");
		return "createblog";
		}
	@RequestMapping("/saveblog")
	public ModelAndView goIn(@ModelAttribute("blo")BlogModel y,HttpServletRequest req){
		ModelAndView m = new ModelAndView("index");
		bd.addBlog(y);
	
	if (!y.getFile().isEmpty()) {
       		String a=req.getSession().getServletContext().getRealPath("/");
		File f=new File(a+"/resources/assets/upimages/");
		if(!f.exists())
			  f.mkdirs();
		Path path=Paths.get(a+"/resources/assets/upimages/"+ y.getTitle()+".jpg");
		try{
		y.getFile().transferTo(new File(path.toString()));
		 System.out.println("uploaded sucessfully");
		} 
		catch(Exception e) {
			System.out.println("e");
		}
		}
		else {
			m.setViewName("index");
         System.out.println("You failed to upload " + y.getTitle() + " because the file was empty.");
		}
	return m;
		  
     }
    @RequestMapping("/views")
	public ModelAndView goIkl(){
		ModelAndView m = new ModelAndView("blogging");
		m.addObject("text",bd.viewBlog());
	return m;
	}
	
	//==================================================================================//
	@RequestMapping("/waste")
	public String gowaste(){
		System.out.println("In waste");
		return "waste";
		}

	@RequestMapping("/chat")
	public String gochat(){
		System.out.println("In chat");
		return "chat";
		
		
		
		}
	@RequestMapping("/viewblogg")
	public String goviewblogg(){
		System.out.println("In viewblogg");
		return "viewblogg";
		}
	
	
	@RequestMapping("/pro")
	public String gopro(){
		System.out.println("In pro");
		return "pro";
		}
	
	@RequestMapping("/new")
	public String gonew(){
		System.out.println("In new");
		return "new";
		}
	
		@RequestMapping("/single")
	public String gosingle(){
		System.out.println("In single");
		return "single";
		}	@RequestMapping("/")
	public String goIndex(){
		System.out.println("In Index");
		return "Index";
		}
	@RequestMapping("/Login")
	public String goLogin(){
		System.out.println("In Login");
		return "Login";
}
	@RequestMapping("/404")
	public String goslider(){
		System.out.println("404");
		return "404";
		}
	@RequestMapping("/logout")
	public ModelAndView handleRequest(HttpServletRequest request, HttpServletResponse response){
	ModelAndView view = new ModelAndView("index");
	request.getSession().invalidate();
	return view;
	} 
	
		
	
	
	
}