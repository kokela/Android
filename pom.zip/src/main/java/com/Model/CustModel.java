package com.Model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Transient;

import org.springframework.web.multipart.MultipartFile;
@Entity
public class CustModel {
	
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private String uid;
	
	@Column
	private String name;
	
	@Column
	private String email;
	
	@Column
	private String phno;
	
	
	@Column
	private String dob;
	
	@Column
	private String pswd;
	
	@Column
	private String cnfrmpswd;
	
	@Column
	private boolean enabled;
	
	@Column
	private String role;

	
	 @Transient
	    private MultipartFile file;

	
	
	public boolean isEnabled() {
		return enabled;
	}


	public void setEnabled(boolean enabled) {
		this.enabled = enabled;
	}


	public String getRole() {
		return role;
	}


	public void setRole(String role) {
		this.role = role;
	}


	public MultipartFile getFile() {
		return file;
	}


	public void setFile(MultipartFile file) {
		this.file = file;
	}


	public String getPhno() {
		return phno;
	}


	public void setPhno(String phno) {
		this.phno = phno;
	}


	public String getDob() {
		return dob;
	}


	public void setDob(String dob) {
		this.dob = dob;
	}


	public String getEmail() {
		return email;
	}


	public void setEmail(String email) {
		this.email = email;
	}


	public String getPswd() {
		return pswd;
	}


	public void setPswd(String pswd) {
		this.pswd = pswd;
	}


	public String getCnfrmpswd() {
		return cnfrmpswd;
	}


	public void setCnfrmpswd(String cnfrmpswd) {
		this.cnfrmpswd = cnfrmpswd;
	}


	

	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}


	public String getUid() {
		return uid;
	}

	public void setUid(String uid) {
		this.uid = uid;
	}

}

