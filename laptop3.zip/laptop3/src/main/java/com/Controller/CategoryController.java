package com.Controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class CategoryController {
	@RequestMapping("/category")
	public String gocategory(){
		return "category";
	}
	
	@RequestMapping("/viewcategory")
	public String goviewcategory(){
		return "viewcategory";
	}
	
	@RequestMapping("/editcategory")
	public String goeditcategory(){
		return "editcategory";
	}
	@RequestMapping("/deletecategory")
	public String godeletecategory(){
		return "deletecategory";
	}
}
