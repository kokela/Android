package Controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class BaseController {

    
    @RequestMapping("/")
    public String image(){
        return "image";
    }
    @RequestMapping("/login")
    public String gologin(){
        return "login";
    }
    @RequestMapping("/register")
    public String goregister(){
        return "register";
    }
}

