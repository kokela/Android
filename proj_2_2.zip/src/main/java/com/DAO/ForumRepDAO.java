package com.DAO;

import java.util.List;

import com.Model.ForumRepModel;

public interface ForumRepDAO {
	void addForumRep(ForumRepModel r);
	List<ForumRepModel> viewAllForumRep();
}
