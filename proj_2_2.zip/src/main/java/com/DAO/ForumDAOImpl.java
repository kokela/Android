/**
 * 
 */
package com.DAO;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.Model.BlogModel;
import com.Model.ForumModel;

@Repository
public class ForumDAOImpl implements ForumDAO {
	
	@Autowired
	SessionFactory sf;
	Session s;
	Transaction t;


	@Override
	@Transactional
	public void addForum(ForumModel f) {
		s=sf.openSession();
		t=s.beginTransaction();
		s.saveOrUpdate(f);
		t.commit();
		
		
	}

	@Override
	public List<ForumModel> viewAllForum() {
		List<ForumModel> l;
	    s=sf.openSession();
		t=s.beginTransaction();
		l = (List<ForumModel>)s.createCriteria(ForumModel.class).list();
		return l;
	}

}
