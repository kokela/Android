package com.DAO;

import java.util.List;

import com.Model.BlogModel;
import com.Model.CustModel;

public interface BlogDAO {
	
	void addBlog(BlogModel b);
	List<BlogModel> viewBlog();


}
