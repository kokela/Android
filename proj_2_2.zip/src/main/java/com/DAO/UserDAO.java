package com.DAO;

import java.util.List;

import com.Model.CustModel;



public interface UserDAO {
	
	void addCust(CustModel c);
	List<CustModel> viewAllCust();
	void editCust(CustModel c);
	CustModel viewCustby(String name);


	

}
