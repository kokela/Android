/**
 * 
 */
package com.DAO;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.Model.ForumModel;
import com.Model.ForumRepModel;

/**
 * @author user
 *
 */

@Repository
public class ForumRepDAOImpl implements ForumRepDAO {
	
	
	@Autowired
	SessionFactory sf;
	Session s;
	Transaction t;


	@Override
	@Transactional
	public void addForumRep(ForumRepModel r) {
		s=sf.openSession();
		t=s.beginTransaction();
		s.saveOrUpdate(r);
		t.commit();
	}

	@Override
	@Transactional
	public List<ForumRepModel> viewAllForumRep() {
		List<ForumRepModel> l;
	    s=sf.openSession();
		t=s.beginTransaction();
		l = (List<ForumRepModel>)s.createCriteria(ForumRepModel.class).list();
		// TODO Auto-generated method stub
		return l;
	}

}
