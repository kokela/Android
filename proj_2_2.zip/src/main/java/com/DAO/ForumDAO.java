package com.DAO;

import java.util.List;

import com.Model.ForumModel;

public interface ForumDAO {
	void addForum(ForumModel f);
	List<ForumModel> viewAllForum();
	

}
