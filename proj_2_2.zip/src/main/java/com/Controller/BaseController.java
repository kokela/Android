package com.Controller;

import java.io.File;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.security.Principal;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.DAO.BlogDAO;
import com.DAO.ForumDAO;
import com.DAO.ForumRepDAO;
import com.DAO.UserDAO;
import com.Model.BlogModel;
import com.Model.CustModel;
import com.Model.ForumModel;
import com.Model.ForumRepModel;


@Controller
public class BaseController {
	
	@Autowired
	UserDAO ud;
	@Autowired
	BlogDAO bd;
	@Autowired
	ForumDAO fd;
	@Autowired
	ForumRepDAO rd;
	
	/*profile
	========================================================================================================*/
	@ModelAttribute("obj")
	public CustModel getOb(){
		return new CustModel();
	}
	@RequestMapping("/save")
	public ModelAndView goInd4(@ModelAttribute("obj")CustModel x,HttpServletRequest req){
		ModelAndView m = new ModelAndView("Index");
		ud.addCust(x);
	
	if (!x.getFile().isEmpty()) {
       		String a=req.getSession().getServletContext().getRealPath("/");
		File f=new File(a+"/resources/assets/upimages/");
		if(!f.exists())
			  f.mkdirs();
		Path path=Paths.get(a+"/resources/assets/upimages/"+ x.getName()+".jpg");
		try{
		x.getFile().transferTo(new File(path.toString()));
		 System.out.println("uploaded sucessfully");
		} 
		catch(Exception e) {
			System.out.println("e");
		}
		}
		else {
			m.setViewName("Register");
         System.out.println("You failed to upload " + x.getName() + " because the file was empty.");
		}
	return m;
		  
     }
	CustModel a ;
	@RequestMapping("/view")
	public ModelAndView goInd2(Principal p){
		ModelAndView m = new ModelAndView("profile");
		m.addObject("data",ud.viewCustby(p.getName()));
		a=ud.viewCustby(p.getName());
	return m;
	}

	
	@RequestMapping("/editCust/{email}")
	public ModelAndView dohil(@PathVariable String email){
	
		//System.out.println("Object : "+q);
		ModelAndView modelandview = new ModelAndView("Register");
		modelandview.addObject("obj",a);
		return modelandview;
	}


	
	
	
	
	/*blog
	 ==============================================================================*/
	
	@RequestMapping("/blogging")
	public String goblogging(){
		System.out.println("In blogging");
		return "blogging";
		} 
	
	@RequestMapping("/blog")
	public String goblog(){
		System.out.println("In blog");
		return "blog";
		}
	@ModelAttribute("blo")
	public BlogModel getblo(){
		return new BlogModel();
	}  
	@RequestMapping("/createblog")
	public String gocreateblog(){
		System.out.println("In createblog");
		return "createblog";
		}
	@RequestMapping("/saveblog")
	public ModelAndView goIn(@ModelAttribute("blo")BlogModel y,HttpServletRequest req){
		ModelAndView m = new ModelAndView("index");
		bd.addBlog(y);
	
	if (!y.getFile().isEmpty()) {
       		String a=req.getSession().getServletContext().getRealPath("/");
		File f=new File(a+"/resources/assets/upimages/");
		if(!f.exists())
			  f.mkdirs();
		Path path=Paths.get(a+"/resources/assets/upimages/"+ y.getTitle()+".jpg");
		try{
		y.getFile().transferTo(new File(path.toString()));
		 System.out.println("uploaded sucessfully");
		} 
		catch(Exception e) {
			System.out.println("e");
		}
		}
		else {
			m.setViewName("index");
         System.out.println("You failed to upload " + y.getTitle() + " because the file was empty.");
		}
	return m;
		  
     }
    @RequestMapping("/views")
	public ModelAndView goIkl(Principal p){
		ModelAndView m = new ModelAndView("blogging");
		
		List<BlogModel>l = bd.viewBlog();
		List<String> ln = new ArrayList<>();
		for(CustModel b:ud.viewAllCust()){
			ln.add(b.getEmail());
			System.out.println(b.getEmail());
		}
		m.addObject("text",l);
		m.addObject("cname",p.getName());
		m.addObject("mname",ln);
		
	return m;
	}

	//forum
	//==================================================================================//
	

    @RequestMapping("/createforum")
	public String gocf(){
		System.out.println("In createforum");
		return "createforum";
	}
    
    @ModelAttribute("for")
	public ForumModel getfor(){
		return new ForumModel();
	}  

    @RequestMapping("/saveforum")
	public ModelAndView goIn(@ModelAttribute("for")ForumModel z,HttpServletRequest req){
		ModelAndView m = new ModelAndView("index");
		fd.addForum(z);
	
	return m;
		  
     }
    @RequestMapping("/viewf")
	public ModelAndView goIndw(){
		ModelAndView m = new ModelAndView("single");
		m.addObject("line",fd.viewAllForum());
		m.addObject("ans",rd.viewAllForumRep());
	return m;
	}
    
    
    @ModelAttribute("rep")
	public ForumRepModel getrep(){
		return new ForumRepModel();
	}  

	
	
	
	 @RequestMapping("/saverep")
		public ModelAndView goIn1(@ModelAttribute("rep")ForumRepModel a,HttpServletRequest req){
			ModelAndView m = new ModelAndView("index");
			rd.addForumRep(a);
		return m;
			  
	     }
	 
	 
	 
	
	 //=================================================================================================================================================//
	 @RequestMapping("/viewblogg")
		public String goviewblogg(){
			System.out.println("In viewblogg");
			return "viewblogg";
		}
	
	
	@RequestMapping("/createb")
	public String gocreateb(){
		System.out.println("In createb");
		return "createb";
	}
	
	@RequestMapping("/Register")
	public String goRegister(){
		System.out.println("In Register");
		return "Register";
	}
	
	
		
	@RequestMapping("/pro")
	public String gopro(){
		System.out.println("In pro");
		return "pro";
		}
	
	@RequestMapping("/new")
	public String gonew(){
		System.out.println("In new");
		return "new";
		}
	
		@RequestMapping("/single")
	public String gosingle(){
		System.out.println("In single");
		return "single";
		}	
		
		
		@RequestMapping("/")
	public String goIndex(){
		System.out.println("In Index");
		return "Index";
		}
	@RequestMapping("/Login")
	public String goLogin(){
		System.out.println("In Login");
		return "Login";
}
	@RequestMapping("/404")
	public String goslider(){
		System.out.println("404");
		return "404";
		}
	@RequestMapping("/logout")
	public ModelAndView handleRequest(HttpServletRequest request, HttpServletResponse response){
	ModelAndView view = new ModelAndView("index");
	request.getSession().invalidate();
	return view;
	} 
	
		
	
	
	
}