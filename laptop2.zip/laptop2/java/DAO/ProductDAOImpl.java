/**
 * 
 */
package DAO;

import java.util.List;

import Model.ProductModel;

/**
 * @author JEGAN
 *
 */
public class ProductDAOImpl implements ProductDAO {

	/* (non-Javadoc)
	 * @see DAO.ProductDAO#addProduct(Model.ProductModel)
	 */
	@Override
	public void addProduct(ProductModel p) {
		// TODO Auto-generated method stub

	}

	/* (non-Javadoc)
	 * @see DAO.ProductDAO#viewProduct(java.lang.String)
	 */
	@Override
	public void viewProduct(String code) {
		// TODO Auto-generated method stub

	}

	/* (non-Javadoc)
	 * @see DAO.ProductDAO#deleteProduct(Model.ProductModel)
	 */
	@Override
	public void deleteProduct(ProductModel p) {
		// TODO Auto-generated method stub

	}

	/* (non-Javadoc)
	 * @see DAO.ProductDAO#editProduct(Model.ProductModel)
	 */
	@Override
	public void editProduct(ProductModel p) {
		// TODO Auto-generated method stub

	}

	/* (non-Javadoc)
	 * @see DAO.ProductDAO#ViewProductModel()
	 */
	@Override
	public List<ProductModel> ViewProductModel() {
		// TODO Auto-generated method stub
		return null;
	}

	/* (non-Javadoc)
	 * @see DAO.ProductDAO#viewProductby(java.lang.String)
	 */
	@Override
	public ProductModel viewProductby(String code) {
		// TODO Auto-generated method stub
		return null;
	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
