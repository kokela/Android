package DAO;

import java.util.List;

import Model.SupplierModel;

public class SupplierDAOImpl implements SupplierDAO {

	@Override
	public void addSupplier(SupplierModel p) {
		// TODO Auto-generated method stub

	}

	@Override
	public void viewSupplier(String code) {
		// TODO Auto-generated method stub

	}

	@Override
	public void deleteSupplier(SupplierModel p) {
		// TODO Auto-generated method stub

	}

	@Override
	public void editSupplier(SupplierModel p) {
		// TODO Auto-generated method stub

	}

	@Override
	public List<SupplierModel> ViewSupplierModel() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public SupplierModel viewSupplierby(String code) {
		// TODO Auto-generated method stub
		return null;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
