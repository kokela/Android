package com.DAO;

import java.util.List;


import com.Model.Order1;

public interface OrderDAO {

	void addOrderDetails(Order1 p);
	void deleteOrderDetails(Order1 p);
    List<Order1>ViewOrderDetailsModel();
    Order1 viewOderDetailsby(String email);
    double getOrderDetailGrandTotal(int cartId);
}
