/**
 * 
 */
package com.DAO;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.Model.ProductModel;
import com.Model.Shipping;

/**
 * @author user
 *
 */
@Repository
@Transactional
public class ShippingDAOImpl implements ShippingDAO {
	
	
	@Autowired
	SessionFactory sf;
	Session s;
	Transaction t;
	
	@Transactional
	@Override
	public void addShipping(Shipping sh) {
		// TODO Auto-generated method stub
		 s = sf.openSession();
		 t = s.beginTransaction();
		s.saveOrUpdate(sh);
		t.commit();
	}
	@Override
	@Transactional
	public Shipping viewShippingby(String id) {
		s = sf.openSession();
		Transaction t = s.beginTransaction();
		Shipping sh = (Shipping) s.load(Shipping.class, id);
		t.commit();
		return sh;
	}

}
