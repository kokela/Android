package com.DAO;

import com.Model.CartItem;
import com.Model.Cart;

public interface CartItemDAO {

	void addCartItem(CartItem cartItem);
	void removeCartItem(CartItem cartItem);
	void removeAllCartItems(Cart cart);
	CartItem getCartItemByProductId(String productId);
}
