package com.DAO;

import com.Model.Shipping;

public interface ShippingDAO {
	void addShipping(Shipping sh);
   Shipping viewShippingby(String id);

}
