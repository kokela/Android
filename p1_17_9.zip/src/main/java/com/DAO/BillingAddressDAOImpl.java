/**
 * 
 */
package com.DAO;

import org.hibernate.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.Model.BillingAddress;


/**
 * @author user
 *
 */
@Repository
@Transactional
public class BillingAddressDAOImpl implements BillingAddressDAO {

	
	
	@Autowired
	SessionFactory sf;
	Session s;
	Transaction t;
	
	@Override
	@Transactional
	public void addBillingAddress(BillingAddress b) {
		// TODO Auto-generated method stub
				 s = sf.openSession();
				 t = s.beginTransaction();
				s.saveOrUpdate(b);
				t.commit();
			}
		
		
		
	

	@Override
	@Transactional
	public BillingAddress viewBillingAdressby(String id) {
		s = sf.openSession();
		Transaction t = s.beginTransaction();
		BillingAddress b = (BillingAddress) s.load(BillingAddress.class, id);
		t.commit();
		return b;
	}

}
