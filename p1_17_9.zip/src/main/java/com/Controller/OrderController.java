package com.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.DAO.OrderDAO;
import com.Model.Order1;
import com.Model.Shipping;

@Controller
public class OrderController {
	
	@Autowired
	OrderDAO od;
	
	@ModelAttribute("orderobj")
	public Order1 getorder(){
		return new Order1();
	}
	@ModelAttribute("shippingobj")
	public Shipping getshipping(){
		return new Shipping();
	}
	@RequestMapping("/checkout")
	public ModelAndView gocheckout(){
		ModelAndView view = new ModelAndView("checkout");
	System.out.println("checkout");
	return view;
	}
	

}
