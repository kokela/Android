package com.Controller;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.Model.ProductModel;
import com.google.gson.Gson;

@Controller
public class BaseController {

	@RequestMapping("/Shipping")
	public String goship(){
		System.out.println("In Shipping");
		return "Shipping";
		
	}
	
	@RequestMapping("/customerDetail")
	public String gocustomerDetail(){
		System.out.println("In customerDetail");
		return "customerDetail";
		
	}
	
	@RequestMapping("/Payment")
	public String goPayment(){
		System.out.println("In Payment");
		return "Payment";
		
	}
	
	@RequestMapping("/checkoutCancelled")
	public String gocheckoutCancelled(){
		System.out.println("In checkoutCancelled");
		return "checkoutCancelled";
		
	}
	
	@RequestMapping("/Login")
	public String goLogin(){
		System.out.println("In Login");
		return "Login";
		
	}
	
	@RequestMapping("/customerfi")
	public String goSupport(){
		System.out.println("customerfi");
		return "customerfi";
	}
	
	
	@RequestMapping("/contact")
	public String gocontact(){
		System.out.println("contact");
		return "contact";
	}
	@RequestMapping("/cart")
	public String gocart(){
		System.out.println("cart");
		return "cart";
	}
	
	
	@RequestMapping("/adminfi")
	public String goadminfi(){
		System.out.println("adminfi");
		return "adminfi";
	}
	
	@RequestMapping("/productdetail")
	public String goproductdetail(){
		System.out.println("productdetail");
		return "productdetail";
	}
	
	
	@RequestMapping("/logout")
	public ModelAndView handleRequest(HttpServletRequest request, HttpServletResponse response){
	ModelAndView view = new ModelAndView("fi");
	request.getSession().invalidate();
	return view;
	} 
	
	
}
