package com.Controller;



import javax.validation.Valid;

//import javax.servlet.http.HttpServletRequest;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.DAO.CustomerDAO;
import com.Model.Customer;

@Controller
public class UserController {

	ModelAndView m;
	
	@Autowired
	CustomerDAO cd;
	
	@RequestMapping("/Register")
	public ModelAndView goRegister(){
		m = new ModelAndView("Register");
		m.addObject("cust", new Customer());
		return m;
	}
	
	@RequestMapping("/addCust")
	public ModelAndView addC(@Valid @ModelAttribute("cust")Customer c,BindingResult br){
		if(br.hasErrors()){
			m= new ModelAndView("Register");
			
			m.addObject("cust", c);
			return m;
		}
			
		m = new ModelAndView("Login");
		 String emailregex = "^[_A-Za-z0-9-]+(\\.[_A-Za-z0-9-]+)*@[A-Za-z0-9-]+(\\.[A-Za-z0-9-]+)*(\\.[A-Za-z]{2,})$";
        if(c.getEmail().matches(emailregex))
        cd.addCustomer(c);
        else{
			m= new ModelAndView("Register");
		     m.addObject("cust", c);
			return m;
        }
		
		return m;
	}
	
	//@RequestMapping("/addCu")
	
	
}
