package com.Model;

import java.io.Serializable;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;

public class Cart implements Serializable {

    
    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue
    public int cartId;
    
    @OneToMany(mappedBy="cart", cascade=CascadeType.ALL,fetch=FetchType.EAGER)
    public List<CartItem> cartItems;

    public double grandTotal;
    @OneToOne
    @JoinColumn(name="id")
    //@JsonIgnore
    public Customer user;
    
    public  ProductModel product;
    
    

    @Id
    @GeneratedValue
    public int getCartId() {
        return cartId;
    }

    public void setCartId(int cartId) {
        this.cartId = cartId;
    }

    public double getGrandTotal() {
        return grandTotal;
    }

    public void setGrandTotal(double grandTotal) {
        this.grandTotal = grandTotal;
    }

	public Customer getUser() {
		return user;
	}

	public void setUser(Customer user) {
		this.user = user;
	}

	public ProductModel getProduct() {
		return product;
	}

	public void setProduct(ProductModel product) {
		this.product = product;
	}
   
    
    
    
    
}