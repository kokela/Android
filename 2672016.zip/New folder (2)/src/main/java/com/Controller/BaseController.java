package com.Controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class BaseController {

	@RequestMapping("/")
	public String goHome(){
		System.out.println("In Controller");
		return "fi";
	}
	@RequestMapping("/Login")
	public String goLogin(){
		System.out.println("In Login");
		return "Login";
		
	}
	
	@RequestMapping("/customerfi")
	public String goSupport(){
		System.out.println("customerfi");
		return "customerfi";
	}
	
	
	@RequestMapping("/adminfi")
	public String goadminfi(){
		System.out.println("adminfi");
		return "adminfi";
	}
	
	@RequestMapping("/cart")
	public String gocart(){
		System.out.println("In cart");
		return "cart";
	}
	
	@RequestMapping("/singleproduct")
	public String gosingleproduct(){
		System.out.println("singleproduct");
		return "singleproduct";
	}
	@RequestMapping("/logout")
	public ModelAndView handleRequest(HttpServletRequest request, HttpServletResponse response){
	ModelAndView view = new ModelAndView("fi");
	request.getSession().invalidate();
	return view;
	} 
	
	
}
