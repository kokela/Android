/**
 * 
 */
package com.DAO;

import java.util.List;

import org.hibernate.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.Model.ProductModel;

@Repository
@Transactional
public class ProductDAOImpl implements ProductDAO {

	/*
	 * (non-Javadoc)
	 * 
	 * @see DAO.ProductDAO#addProduct(Model.ProductModel)
	 */
	@Autowired
	SessionFactory sf;

	@Transactional(propagation = Propagation.REQUIRED)
	public void addProduct(ProductModel p) {
		// TODO Auto-generated method stub
		Session s = sf.openSession();
		Transaction t = s.beginTransaction();
		s.saveOrUpdate(p);
		t.commit();
	}

	public void viewProduct(String code) {
		// TODO Auto-generated method stub

	}

	@Transactional(propagation = Propagation.REQUIRED)
	public void deleteProduct(ProductModel p) {
		// TODO Auto-generated method stub
		Session s = sf.getCurrentSession();
		Transaction t = s.beginTransaction();
		ProductModel q = new ProductModel();
		q.setcode(p.getcode());
		q.setname(p.getname());
		s.delete(q);
		t.commit();
		// s.close();
	}

	@Transactional(propagation = Propagation.REQUIRED)
	public void editProduct(ProductModel p) {
		// TODO Auto-generated method stub

	}

	@Transactional(propagation = Propagation.REQUIRED)
	public List<ProductModel> ViewProductModel() {
		// TODO Auto-generated method stub

		Session s = sf.openSession();
		Transaction t = s.beginTransaction();
		List<ProductModel> l = s.createCriteria(ProductModel.class).list();
		t.commit();
		return l;
	}

	@Transactional(propagation = Propagation.REQUIRED)
	public ProductModel viewProductby(String code) {
		// TODO Auto-generated method stub
		Session s;
		/*
		 * if(sf.getCurrentSession()!=null) { s=sf.getCurrentSession(); } else
		 */
		s = sf.openSession();
		Transaction t = s.beginTransaction();
		ProductModel p = (ProductModel) s.load(ProductModel.class, code);
		t.commit();
		return p;
	}

}
